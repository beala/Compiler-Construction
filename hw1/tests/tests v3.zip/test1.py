x=input() + 20
y=input() + 21
z=input() + 23
tmp0=1
tmp1=1
tmp2=1
tmp3=1
tmp4=1
tmp5=1
tmp6=1
tmp7=1
tmp8=1
tmp8=1
tmp10=1
tmp11=1
tmp12=1
tmp13=1
tmp14=1
tmp15=1
tmp16=1
tmp17=1
tmp18=1
tmp19=1
tmp20=1
print x
print y
print z

