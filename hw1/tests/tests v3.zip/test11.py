x=10
y=22
z=33
x+y+z+input()
x=input()
print x

