tmp3=10
print 1+2+3+input()
print tmp3
