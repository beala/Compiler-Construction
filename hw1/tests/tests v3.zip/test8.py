tmp1=input()
tmp1=1
tmp0=2
print tmp0
