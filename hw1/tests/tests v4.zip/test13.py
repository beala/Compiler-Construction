----------------------input()
print input()
