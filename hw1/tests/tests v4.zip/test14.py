alex=10
alex=-alex
alex=-alex
alex=-alex
alex=alex+-alex+-alex+1000
print alex
