input()
x=input()
print x
