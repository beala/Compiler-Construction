tmp0=input()
tmp1=-tmp0+100
tmp0=-tmp0
-tmp0
print tmp0
print tmp1
