tmp0=1
tmp0=2
tmp0=3
print tmp0 + -input()
