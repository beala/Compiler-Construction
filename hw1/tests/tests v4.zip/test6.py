tmp0=1
tmp1=2
tmp2=3
tmp3=4
tmp4=5
tmp5=6
tmp6=7
tmp7=8
tmp8=9
tmp9=10
tmp10=11
x=10
y=22
t=556
wer=345
print x+y+t+wer+12
print x+y+-t+wer+343
print x+y+t
print y+x+t+234
print tmp0
print tmp1
print tmp2
print tmp3
print tmp4
print tmp5
print tmp6
print tmp7
print tmp8
print tmp9
print tmp10
