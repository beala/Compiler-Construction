tmp0=input()
tmp0=1
print tmp0
