tmp1=1
print tmp1 + 100
